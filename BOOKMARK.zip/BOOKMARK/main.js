var webname=document.getElementById("name");
var webURL=document.getElementById("link");
var bottun=document.getElementById("sdtn");
var t=document.getElementById("tbody");
var localstor=localStorage.getItem("Site");
var sites=[];

if(localstor)
{
     sites=JSON.parse(localstor);
}
showData();

function main(){
     getsite();
     clearinputs();
     showData();
}

function getsite()
{
     if(!bottun.hasAttribute("data-bs-toggle")||!bottun.hasAttribute("data-bs-target")){
          var site=
          {
               name:webname.value,
               url:webURL.value
          }
          sites.push(site);
          localStorage.setItem("Site",JSON.stringify(sites));
     }
}

function clearinputs()
{
     webname.value="";
     webURL.value="";
}

function showData()
{

     var Data=``;
     for (let i= 0; i < sites.length; i++) {
           console.log()
           Data+=`
           <tr>

               <td>${i+1}</td>
               <td>${sites[i].name}</td>
               <td><a type="button" href="${sites[i].url}" class="btn btn-success"><i class="fa-solid fa-eye"></i> Visit</a></td>
               <td><button type="button" onclick="DeleteData(${i})" class="btn btn-danger"> <i class="fa-solid fa-trash"></i> Delete</button></td>
               
          </tr>
           `
     }
     t.innerHTML=Data;

}

function DeleteData(i)
{
     sites.splice(i,1);
     showData();
     localStorage.setItem("Site",JSON.stringify(sites));
}

function check1(){
     var regex=/^https:\/\/www.[a-zA-Z1-9]{2,20}\.[a-zA-Z]{2,5}$/;
     
     if(!regex.test(webURL.value)){
          bottun.setAttribute("data-bs-toggle","modal");
          bottun.setAttribute("data-bs-target","#exampleModal");
          webURL.style=`
               color:  #212529 !important;
               background-color: #fff !important;
               border-color: red !important;
               box-shadow: 0 0 0 0.25rem #ff000055 !important;
          `
          webURL.classList.add("is-invalid");
     }else{
          bottun.removeAttribute("data-bs-toggle");
          bottun.removeAttribute("data-bs-target");
          webURL.style=`
               color: #212529;
               background-color: #fff;
               border-color: #d99c39;
               box-shadow: 0 0 0 0.25rem #fec26055;
          `
          webURL.classList.add("is-invalid");
     }
     if(!webURL.value){
          webURL.style=`
               color: #212529;
               background-color: #fff;
               border-color: #d99c39;
               box-shadow: 0 0 0 0.25rem #fec26055;
          `
          webURL.classList.remove("is-invalid");
     }
}

function check2(){
     var regex2=/[a-zA-Z1-9]{3,}/gm;
     if(!regex2.test(webname.value)){
          bottun.setAttribute("data-bs-toggle","modal");
          bottun.setAttribute("data-bs-target","#exampleModal");
          webname.style=`
               color:  #212529 !important;
               background-color: #fff !important;
               border-color: red !important;
             
               box-shadow: 0 0 0 0.25rem #ff000055 !important;
          `
          webname.classList.add("is-invalid");
     }else{
          bottun.removeAttribute("data-bs-toggle");
          bottun.removeAttribute("data-bs-target");
          webname.style=`
               color: #212529;
               background-color: #fff;
               border-color: #d99c39;
               box-shadow: 0 0 0 0.25rem #fec26055;
          `
          webname.classList.remove("is-invalid");
     }
     if(!webname.value){
          webname.style=`
               color: #212529;
               background-color: #fff;
               border-color: #d99c39;
               box-shadow: 0 0 0 0.25rem #fec26055;
          `
          webname.classList.remove("is-invalid");
     }
}